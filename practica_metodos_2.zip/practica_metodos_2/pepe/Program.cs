﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using static practica_metodos_2.antillana; //porque me lo detecta como inecesario?

namespace practica_metodos_2
{
    public class GestInscripcions
    {
        //cuando es necesario usar los métodos como string int, dentro del void y cuando es necesario separarlos y ponerlos fuera

        const int REGISTRO_EXISTENTE = -1;
        const int REGISTRO_INEXISTENTE = -1;
        const int REGISTRO_NULO = -7;
        const int REGISTRO_NULL = -7;

        const int INSCRIPCIONES_NULO = -8;

        const int ACTIVIDAD_INEXISTENTE = -5;
        const int INSCRIPCION_INEXISTENTE = -5;

        antillana pep = new antillana(); //se puede declarar una clase de manera global?, como anteriormente esto no estaba bien, pero las constantes si están declararadas de forma global

        public void arrActividades()
        {
            String[,] actividades = pep.cargarActividades();
            activitiesi(actividades);
        }

        public void arrAlumnos()
        {
            String[,] alumnos = pep.cargarAlumnos(); //puede ser que no muestre el array alumnos desde este método porque al llamarlo desde aquí te llama al array vacó del otro lado?

            mostrarAlumnos(alumnos);
        }

        public void arrInscripciones()
        {
            String[,] inscripciones = pep.cargarInscripciones();
            inscriptiones(inscripciones);
        }

        public void activitiesi(String[,] actividades)
        {
            for (int i = 0; i < actividades.GetLength(0); i++)
            {
                for (int o = 0; o < actividades.GetLength(0); o++)
                {
                    Console.Write(actividades[i, o] + "\t");
                    Console.WriteLine();
                }
            }
            Console.WriteLine();
        }

        public void inscriptiones(String[,] inscripciones)
        {
            for (int i = 0; i < inscripciones.GetLength(0); i++)
            {
                for (int j = 0; j < inscripciones.GetLength(1); j++)
                {
                    Console.Write(inscripciones[i, j] + "\t");
                }
            }
            Console.WriteLine();
        }

        public void mostrarAlumnos(String[,] alumnos)
        {
            Console.WriteLine("\nNIF\t\tNombre");

            for (int u = 0; u < alumnos.GetLength(0); u++)
            {
                for (int o = 0; o < alumnos.GetLength(1); o++)
                {
                    Console.Write(alumnos[u, o] + "\t");
                }
                Console.WriteLine();
            }

        }
        public void agregarAlumnos(String[,] alumnos)
        {
            String nombre;
            String nif;

            int fila;

            nombre = pedirNombre();
            nif = pedirNif();

            fila = comprobarAlumnos(nif, alumnos);

            if (fila == REGISTRO_EXISTENTE)
            {
                Console.WriteLine("Este alumno ya existe, su nombre es: " + nombre); //ESTA BIEN ASÍ O HAY QUE LLAMAR A LA POSICIÓN DEL ARRAY?
            }

            else
            {
                if (fila == REGISTRO_NULO)
                {
                    Console.WriteLine("ARRAY LLENO");

                }
                else
                {
                    alumnos[fila, 0] = nif;
                    alumnos[fila, 1] = nombre;
                }
            }
            mostrarAlumnos(alumnos);

            fila = 0;
        }

        public int comprobarAlumnos(String nif, String[,] alumnos)
        {
            int fila = 0;
            bool final = false;
            bool existe = false;

            while (fila < alumnos.GetLength(0) & !existe)
            {
                if (alumnos[fila, 0] == null)
                {
                    final = true;
                    break;
                }

                if (alumnos[fila, 0] == nif)
                {
                    existe = true;
                    break;
                }

                fila++;
            }

            if (existe)
            {
                return REGISTRO_EXISTENTE;
            }

            else  //si es redundante es necesario ponerlo? EL ELSE
            {
                if (final)
                {
                    return fila;
                }

                else
                {
                    return REGISTRO_NULO;
                }
            }
        }

        public int comprobarNif(String nif, String[,] alumnos)// ESTE MÉTODO PODRÍA SER REDUNDANTE, PERO NO LO ES PORQUE TE DEVUELVE LA FILA EN QUE EXISTE EL NIF Y EN ELLO TE DA EL NOMBRE
        {
            int fila = 0;
            bool existe = false;

            while (fila < alumnos.GetLength(0) & !existe)   // PROBAR CON EL MÉTODO ANTERIOR, CON UN REGISTRO_EXISTENTE SE PUEDE REUTILIZAR EL MÉTODO
            {
                if (alumnos[fila, 0] == nif)
                {
                    existe = true;
                    break;
                }
                else
                {
                    fila++;
                }

            }

            if (existe)
            {
                return fila;
            }

            else
            {
                return REGISTRO_NULL;
            }

        }
        public int comprobarActividad(String actividad, String[,] actividades)// HAY QUE HACER OTRO MÉTODO PARA COMPROBAR NIF NOMBRE O HAY QUE USAR EL MISMO?
        {
            int filaactividad = 0;
            bool existe = false;

            while (filaactividad < actividades.GetLength(0) & !existe)
            {
                if (actividades[filaactividad, 0] == actividad)
                {
                    existe = true;
                    break;
                }
                else
                {
                    filaactividad++;
                }

            }

            if (existe)
            {
                return filaactividad;
            }

            else
            {
                return ACTIVIDAD_INEXISTENTE;
            }
        }

        public int comprobarInscripcion(String nif, String[,] inscripciones)// HAY QUE HACER OTRO MÉTODO PARA COMPROBAR NIF NOMBRE O HAY QUE USAR EL MISMO?
        {
            int filainscripcion = 0;

            bool existe = false;

            //me he planteado usar el mismso método para devolverte la fila tanto si estuviera null como .Equals
            //pero entonces se tendría que filtrar en el otro método con el parámetro booleano del método anterior

            while (filainscripcion < inscripciones.GetLength(0) & !existe)
            {
                if (inscripciones[filainscripcion, 0] == nif)
                {
                    existe = true;
                    break;
                }

                filainscripcion++;

            }

            if (existe)
            {
                return filainscripcion;
            }
            else
            {
                return INSCRIPCION_INEXISTENTE;
            }
        }
        public int comprobarInscripciones(String nif, String[,] inscripciones)// HAY QUE HACER OTRO MÉTODO PARA COMPROBAR NIF NOMBRE O HAY QUE USAR EL MISMO?
        {
            int filainscripciones = 0;

            bool final = false;

            while (filainscripciones < inscripciones.GetLength(0) & !final)
            {
                if (inscripciones[filainscripciones, 0] == null)
                {
                    final = true;
                    break;
                }
                filainscripciones++;


            }

            if (final)
            {
                return filainscripciones;
            }

            else
            {
                return INSCRIPCIONES_NULO;
            }





        }

        public void fechaAltaUsuarioVigenta(String[,] alumnos, String[,] actividades, String[,] inscripciones) // REGISTRO EN ARRAY CLIENTE
        {
            String actividad;
            String respuesta;
            String respuestaAlumno;
            String nif;
            String nombre;
            String read;

            int filaAlumno;
            int fila;
            int filaActividad;
            int filaInscripcion;
            int filaInscripciones;



            nif = pedirNif();

            fila = comprobarNif(nif, alumnos);

            if (fila == REGISTRO_NULL)
            {
                Console.WriteLine("Este alumno no existe");
                Console.WriteLine();
                Console.Write("Se quiere dar de alta al alumno? s/n ");
                respuestaAlumno = Console.ReadLine(); //ToLower o ToUpper

                if (respuestaAlumno.Equals("s"))
                {
                    Console.WriteLine("¿Cual es tu nombre?");
                    nombre = Console.ReadLine();

                    filaAlumno = comprobarAlumnos(nif, alumnos);

                    if (filaAlumno == REGISTRO_EXISTENTE)
                    {
                        Console.WriteLine("Este alumno ya existe, su nombre es: " + nombre); //ESTA BIEN ASÍ O HAY QUE LLAMAR A LA POSICIÓN DEL ARRAY? PORQUE SE PREGUNTA DOS VECES??
                    }

                    else
                    {
                        if (filaAlumno == REGISTRO_NULO)
                        {
                            Console.WriteLine("ARRAY LLENO");
                        }
                        else
                        {
                            alumnos[filaAlumno, 0] = nif;
                            alumnos[filaAlumno, 1] = nombre;
                        }
                    }

                }
                else
                {
                    Console.WriteLine("Interesante elección");
                }

            }


            else //aquí ya sabes que el NIF EXISTE EN EL DE ALUMNOS
            {
                Console.WriteLine("Este alumno ya existe, su nombre es: " + alumnos[fila, 1]);

                actividad = pedirActividad();

                filaActividad = comprobarActividad(actividad, actividades);


                if (filaActividad == ACTIVIDAD_INEXISTENTE)
                {
                    Console.WriteLine("Este actividad no existe");
                }

                else  //EXISTE UNA ACTIVIDAD CON ESTE CÓDIGO
                {
                    Console.WriteLine("Esta actividad existe, es la: " + actividades[filaActividad, 1]);

                    // EL NIF Y LA ACTIVIDAD EXISTE








                    filaInscripcion = comprobarInscripcion(nif, inscripciones);  // ¿ESTÁ ESTE NIF REGISTRADO EN LA INSCRIPCIÓN?


                    if (inscripciones[filaInscripcion, 1] == actividades[filaActividad, 1])  //EN LA FILA DEL NIF ESTA REGISTRADA ESTA ACTIVIDAD?
                    {
                        Console.WriteLine("Este alumno ya está inscrito en esta actividad");
                    }


                    if (filaInscripcion == INSCRIPCION_INEXISTENTE)
                    {
                        Console.WriteLine("El nif no esta registrado con esta actividad");

                        Console.Write("¿Los datos son correctos? " + nif + " " + actividades[filaActividad, 1] + " s/n ");
                        respuesta = Console.ReadLine();

                        if (respuesta.Equals("s")) //en caso afirmativo añadir en el array inscripciones una fila con el Nif y Actividad.
                        {
                            filaInscripciones = comprobarInscripciones(nif, inscripciones);


                            if (filaInscripciones == INSCRIPCIONES_NULO)
                            {
                                Console.WriteLine("INSCRIPCIONES LLENAS");
                            }

                            else
                            {
                                inscripciones[filaInscripciones, 0] = nif;
                                inscripciones[filaInscripciones, 1] = actividades[filaActividad, 1];
                            }

                        }
                        else
                        {
                            Console.WriteLine(" ¿Prefieres introducirlos nuevamente? s/n ");
                            read = Console.ReadLine();
                            if (read.Equals("s")) //en caso afirmativo añadir en el array inscripciones una fila con el Nif y Actividad.
                            {
                                fechaAltaUsuarioVigenta(alumnos, actividades, inscripciones);
                            }
                            else
                            {
                                Console.WriteLine(" OK, see you soon");
                            }

                        }



                    }
                    else
                    {


                        else
                        {

                        }
                    }
                }
            }

            /*if (habslibres >= 1)
            {

                Console.WriteLine("Hay " + habslibres + " habitaciones libres de " + camas + " camas");

                habs = pedirHabs();

                nif = pedirNIF();
                user = pedirUsuario();
                email = pedirEmail();


                while (numero != habs)
                {

                    filaNif = nifregistrado(nif, camas, hotel);

                    if (filaNif == HOTEL_NULO)
                    {
                        Console.WriteLine("HABITACIONES LLENAS");
                        break;
                    }

                    else
                    {
                        hotel[filaNif, COL_NIF_HOTEL] = nif; //==fila null y no es verdad, porque tu quieres registrarlo en la fila que le corresponda a las habs que ha pedido
                    }

                    numero++;
                }*/

        }

        public string pedirActividad()
        {
            string actividad;

            Console.WriteLine(" (Escribir el código de la actividad) Te quieres apuntar?");
            Console.WriteLine("(1) Salida a esquiar (2) Salida a Port Aventura (3) Feria Games World ");
            actividad = Console.ReadLine();

            return actividad;

        }

        public string pedirNombre()
        {
            string nombre;

            Console.WriteLine("Nombre: ");
            nombre = Console.ReadLine();

            return nombre;

        }

        public string pedirNif()
        {
            string nif;

            Console.WriteLine("NIF: ");
            nif = Console.ReadLine();

            return nif;
        }
    }
}
