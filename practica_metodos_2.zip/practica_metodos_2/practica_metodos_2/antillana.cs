﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace practica_metodos_2
{
    internal class antillana
    {
        
        // InscripcionesInicio.java (donde tendremos el método inicio, el menú y los arrays)


        public void Inicio()
        {

            String[,] alumnos = cargarAlumnos();  //Console.WriteLine("\nNIF\t\tNombre");
            String[,] inscripciones = cargarInscripciones();  //Console.WriteLine("\nNIF\t\tCódigo actividad");
            String[,] actividades = cargarActividades();

            GestInscripcions hack = new GestInscripcions();

            bool salir = false;
            string opcion;

            do
            {
                mostrarMenu();
                opcion = pedirOpcionMenu();
                salir = ejecutarOpcionesMenu(opcion, alumnos, actividades, inscripciones);

            } while (!salir);
        }

        public string pedirOpcionMenu()
        {
            string opcion;

            do
            {
                Console.Write("Opcion: ");
                opcion = Console.ReadLine();

            } while (!"012345678".Contains(opcion));

            return opcion;
        }

        public bool ejecutarOpcionesMenu(String opcion, String[,] alumnos, String[,]actividades, String[,] inscripciones)
        {

            GestInscripcions hack = new GestInscripcions();
            bool salir = false;

            switch (opcion)
            {
                case "1":
                    hack.agregarAlumnos(alumnos);
                    break;

                case "2":
                    hack.arrActividades(); //cargarActividades()  //se puede parametrizar //y se puede llamar en la otra clase a esta y con un método parametrizado se puede utilizar //esta bien declarar un metodo dentro?
                    break;
                case "3":
                    hack.fechaAltaUsuarioVigenta(alumnos, actividades, inscripciones);
                    break;
                case "4":
                    hack.mostrarAlumnos(alumnos);
                    break;
                case "5":
                    hack.arrAlumnos();
                    break;
                case "6":
                    hack.inscriptiones(inscripciones);
                    break;
                case "7":
                    hack.listaInscripcionesActividad(alumnos, actividades, inscripciones);
                    break;
                case "0":
                    salir = true;
                    break;
            }

            return salir;
        }

        public void mostrarMenu() //métodos no tipados que realizan una tarea específica, pero no necesitan devolver un valor
        {
            Console.WriteLine("1. Añadir alumnos ");
            Console.WriteLine("2. Añadir inscripción ");
            Console.WriteLine("3. Lista de inscripciones de una actividad ");
            Console.WriteLine("4. Mostrar alumnos ");
            Console.WriteLine("5. Mostrar alumnos desde el el método en que esta guardado el array ");
            Console.WriteLine("6. Mostrar inscripciones ");
            Console.WriteLine("7. Mostrar inscripciones ");
            Console.WriteLine("0. Salir ");

        }
        public String[,] cargarActividades()
        {
            String[,] actividades =   //Console.WriteLine("\nCódigo actividad\t\tNombre actividad");
           {{"1", "Salida a esquiar"},
            {"2", "Salida a Port Aventura" },
            { "3", "Feria Games World" } };

            return actividades;
        }
        public String[,] cargarAlumnos() //guardar en un método un array vacío es de guapos
        {
            String[,] alumnos = new String[50, 2]; 
            return alumnos;
        }
        public String[,] cargarInscripciones()
        {
            String[,] inscripciones = new String[50, 2];
            return inscripciones;
        }
    }
}
