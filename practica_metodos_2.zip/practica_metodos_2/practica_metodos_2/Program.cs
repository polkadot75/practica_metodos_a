﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practica_metodos_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //cambiar nombre del archivo a  Inscripciones.java (donde tendremos el método main)

            antillana app =new antillana();
            app.Inicio();

        }
    }
}
